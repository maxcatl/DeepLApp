package com.maxcatl.deepl;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttp;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private Button btnTraduire;
    private EditText editTextOri;
    private TextView textViewTra;
    private Spinner spinnerOri;
    private Spinner spinnerTra;
    private String url = "https://api-free.deepl.com/v2/translate?auth_key=68e6390d-b0ad-efe2-01b3-240a5af9093b%3Afx";
    private String langOri;
    private String langTra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnTraduire = findViewById(R.id.buttonTranslate);
        editTextOri = findViewById(R.id.editTextOriginal);
        textViewTra = findViewById(R.id.textTranslated);
        spinnerOri = findViewById(R.id.spinnerOriginal);
        spinnerTra = findViewById(R.id.spinnerTranslate);
        langOri = "none";
        langTra = "en";

        spinnerOri.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch(position)
                {
                    case 0:
                        langOri = "none";
                        break;

                    case 1:
                        langOri = "en";
                        break;

                    case 2:
                        langOri = "fr";
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        spinnerTra.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch(position)
                {
                    case 0:
                        langTra = "en";
                        break;

                    case 1:
                        langTra = "fr";
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        btnTraduire.setOnClickListener(v -> {
            run();

            // Remise à 0 de l'url
        url = "https://api-free.deepl.com/v2/translate?auth_key=68e6390d-b0ad-efe2-01b3-240a5af9093b%3Afx";

        });
    }

    public void run()
    {

        //Prépare le texte à traduire pour être mis dans le lien
        String text = editTextOri.getText().toString();
        text = text.replace(" ", "%20");
        text = text.replace("\n", "%0A");

        //ajoute le texte et la langue de traduction dans l'url
        url += "&text=" + text;
        url += "&target_lang=" + langTra;

        //ajoute la langue d'origine dans l'url si elle est spécifiée
        if (!langOri.equals("none"))
        {
            url += langOri;
        }

        //création du client http et de la requête
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder() .url(url) .build();

        client.newCall(request).enqueue(new Callback() {
            /**
             * Si la requête http n'a pas abouti
             * @param call
             * @param e
             */
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                call.cancel();
            }

            /**
             * lorsque la requête a abouti
             * @param call
             * @param response
             * @throws IOException
             */
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {

                final String myResponse = response.body().string();

                //on créer un autre thread pour chercher la traduction et la mettre dans le text view
                MainActivity.this.runOnUiThread(() -> {
                    try {
                        JSONObject reponseJSON = new JSONObject(myResponse);

                        JSONArray tableauJSON = reponseJSON.getJSONArray("translations");

                        String traduction = tableauJSON.optJSONObject(0).optString("text");

                        textViewTra.setText(traduction);
                    }
                    catch (JSONException e)
                    {
                        System.err.println("error on the JSON");
                        e.printStackTrace();
                    }
                });
            }
        });

    }
}